part of 'reminder_bloc.dart';

abstract class ReminderEvent extends Equatable {
  const ReminderEvent();

  @override
  List<Object> get props => [];
}

class LoadReminders extends ReminderEvent {
  final DateTime selectedDate;

  const LoadReminders(this.selectedDate);

  @override
  List<Object> get props => [selectedDate];
}

class DateChanged extends ReminderEvent {
  final DateTime selectedDate;

  const DateChanged(this.selectedDate);

  @override
  List<Object> get props => [selectedDate];
}

class AddNewReminder extends ReminderEvent {} 

class SaveReminders extends ReminderEvent {} 