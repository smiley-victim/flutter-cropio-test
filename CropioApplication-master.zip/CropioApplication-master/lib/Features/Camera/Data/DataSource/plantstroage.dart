abstract class PlantStorage {
  Future<void> uploadImage();
}

class PlantstroageService extends PlantStorage {
  @override
  Future<void> uploadImage() {
    // TODO: implement uploadImage
    throw UnimplementedError();
  }

}