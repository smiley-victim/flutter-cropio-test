import 'package:flutter/material.dart';

const s10 = SizedBox(height: 10, width: 10);

const s50 = SizedBox(height: 50, width: 50);

const s25 = SizedBox(height: 25, width: 25);

const s100 = SizedBox(height: 100, width: 100);

const s5 = SizedBox(height: 5,width: 5,);

const nothing = SizedBox.shrink();

const productName = "Project-SM";