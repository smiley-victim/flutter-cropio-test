
import 'package:get_it/get_it.dart';


final servicelocator = GetIt.instance;

Future<void> setupAndInitDependencies() async {
  
  

  /// here the storage is inilialized =>



}